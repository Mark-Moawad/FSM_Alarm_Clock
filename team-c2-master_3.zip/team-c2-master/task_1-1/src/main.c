#include <avr/io.h>
#include <util/delay.h>

/**Toggles the red LED of the SES-board*/
/*If PORTGn is written logic one when the PORTG pin n is configured as an input pin, the
pull-up resistor is activated. To switch the pull-up resistor off, PORTGn has to be written
logic zero or the pin has to be configured as an output pin. If PORTGn is written logic
one when the pin is configured as an output pin, the port pin is driven high (one). If
PORTGn is written logic zero when the pin is configured as an output pin, the port pin is
driven low (zero)*/
/*The DDGn bit in the DDRG Register selects the direction of the PORTG pin n. If DDGn
is written logic one, PGn is configured as an output pin. If DDGn is written logic zero,
PGn is configured as an input pin.*/
int main(void) {
	DDRG |= 0x02;
	while (1) {
		_delay_ms(2000);
		PORTG ^= 0x02;
	}
	return 0;
}
