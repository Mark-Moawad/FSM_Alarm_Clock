#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

int main(void)
{
    uint8_t x = 0, temp = 0xa0;
    // setting bit 3
    x = x | 0x8;
    printf("setting bit 3 x = %04x\n", x);

    // setting bit 4 and 6 without shifting
    x = 0;
    x = x | 0x50;
    printf("setting bits 4 and 6 without shifting x = %04x\n", x);

    // setting bit 4 and 6 with shifting
    x = 6;
    temp = temp >> 1;
    x = x | temp;
    printf("setting bits 4 and 6 with shifting x = %04x\n", x);

    // setting bit 4 and 6 with shifting
    x = 0x00;
    x = x | ((0x1 << 4) | (0x1 << 6));
    printf("setting bits 4 and 6 with shifting x = %04x\n", x);

    // Clear bit 2 with shifting
    x = 0xFF;
    x = x & ~(1 << 2);
    printf("Clear bit 2 x = %04x\n", x);

    // Clear bits 2 and 7 with shifting
    x = 0xFF;
    x = x & ~((0x1 << 2) | (0x1 << 7));
    printf("Clear bits 2 and 7 x = %04x\n", x);

    // Toggle bit 3
    x = 0;
    x = x ^ (0x08);
    printf("Toggle bit 3 x = %04x\n", x);
    

    // Set bit 2 and clear bits 5 and 7 at the same time
    x = 0xf0;
    x = (x & ~((0x1 << 5) | (0x1 << 7))) | (0x1 << 2) ;
    printf("Set bit 2 and clear bits 5 and 7 at the same time x = %04x\n", x);

    // Swap bits 3-5 and bits 0-2
    x = 0x69;
    x = (x & 0xC0) | ((x >> 3) & 0x7) | ((x << 3) & 0x38);
    printf("Swap bits 3-5 and bits 0-2 x = %04x\n", x);
    return 0;
}