/*INCLUDES *******************************************************************************/
#include "ses_timer.h"
#include "ses_uart.h"
#include "ses_lcd.h"
#include "ses_scheduler.h"
/*Variables Declaration ******************************************************************/
taskDescriptor task1;
/*FUNCTION DEFINITIONS *******************************************************************/
#define TASK1_PERIOD 1000
/*FUNCTION Declaration *******************************************************************/
void lcd_display(void *);

int main()
{
    //initializing taskDescriptor 1
    task1.task = lcd_display;
    task1.param = NULL;
    task1.period = TASK1_PERIOD;
    task1.expire = task1.period;
    task1.execute = true;

    // Uart init
    uart_init(57600);

    //LCD init
    lcd_init();

    //Scheduler init
    scheduler_init();
    scheduler_add(&task1);
    //enable global interrupt
    sei();
    while (1)
    {
        scheduler_run();
    }

    return 0;
}
void lcd_display(void *param)
{
    // lcd_clear();
    // lcd_setCursor(0, 1);
    // fprintf(lcdout, "Frequency = %u RPM", (motorFrequency_getRecent() * RPM_MULTIPLICATION_FACTOR));
    // lcd_setCursor(0, 2);
    // fprintf(lcdout, "Med Freq = %u Hz", motorFrequency_getMedian());
    // fprintf(uartout, "Med Freq = %u Hz \n", motorFrequency_getMedian());
    //fprintf(uartout, "MARK & Khaled Galaaaaaaaaaaaaaaaal\n");
    fprintf(uartout, "Time = %u:%u:%u  \n", scheduler_calc_time().hour, scheduler_calc_time().minute, scheduler_calc_time().second);
}
