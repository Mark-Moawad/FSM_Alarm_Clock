#include "ses_lcd.h"
#include "ses_uart.h"
#include <util/delay.h>
#include "ses_led.h"
#include "ses_button.h"
#include "ses_adc.h"
#include "ses_timer.h"

/* function prototypes ******************************************/
void softwareTimer(void);
void softwareTimer1(void);
void softwareTimer1_2(void);

int main(void)
{   
    led_redInit();
    led_yellowInit();
    timer2_setCallback(&softwareTimer);
    timer2_start();
    timer1_setCallback(&softwareTimer1);
    timer1_start();
    sei();
    while (1)
    {

    }
    return 0;
}

void softwareTimer(void)
{
	static uint16_t count = 0;
	//1000 counts for each second
	if (count < 1000)
	{
		count++;
	}
	else
	{
		led_yellowToggle();
		count = 0;
	}
}
void softwareTimer1(void)
{
	static uint16_t count1 = 0;
	//200 counts for each second
	//setting the timer for 1 second:
	if (count1 < 200)
	{
		count1++;
	}
	else
	{
		led_redToggle();
		count1 = 0;
	}
}

void softwareTimer1_2(void)
{
	static uint16_t count2 = 0;
	//200 counts for each second
	//setting the timer for 5 seconds:
	if (count2 < 1000)
	{
		count2++;
	}
	else
	{
		led_greenToggle();
		count2 = 0;
	}
}