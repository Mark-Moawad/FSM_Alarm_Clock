#include "ses_lcd.h"
#include "ses_uart.h"
#include <util/delay.h>
#include "ses_led.h"
#include "ses_button.h"
#include "ses_adc.h"

int main(void)
{
    int16_t adc_val = 0;
    adc_init();
    uart_init(57600);
    lcd_init();
    while (1)
    {
        //adc_val = adc_read(ADC_LIGHT_CH);
        adc_val = adc_read(ADC_TEMP_CH);
        UART_DEBUG(adc_val);
        _delay_ms(1000);
    }
    return 0;
}