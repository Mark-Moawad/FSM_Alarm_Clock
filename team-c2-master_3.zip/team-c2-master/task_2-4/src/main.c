#include "ses_lcd.h"
#include "ses_uart.h"
#include <util/delay.h>
#include "ses_led.h"

void wait(uint16_t millis)
{
    uint32_t i = 0;
    for (i = (uint32_t)(millis)*2000; i > 0; i--)
    {
        asm volatile("nop");
        asm volatile("nop");
    }
}
int main(void)
{
    led_redInit();
    led_yellowInit();
    led_greenInit();
    while (1)
    {
        /*led_redOn();
        led_yellowOn();
        led_greenOn();
        wait(2000);
        led_redOff();
        led_yellowOff();
        led_greenOff();
        wait(2000);*/
        //Traffic Lights simulation :D
        led_redOff();
        led_yellowOff();
        led_greenOff();
        for (uint8_t i = 10; i > 0; i--)
        {
            led_redToggle();
            wait(2000);
        }
        for (uint8_t i = 10; i > 0; i--)
        {
            led_yellowToggle();
            wait(2000);
        }
        for (uint8_t i = 10; i > 0; i--)
        {
            led_greenToggle();
            wait(2000);
        }
        
    }
    return 0;
}