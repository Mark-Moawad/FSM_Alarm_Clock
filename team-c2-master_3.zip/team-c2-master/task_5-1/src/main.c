/*INCLUDES *******************************************************************/
#include "ses_button.h"
#include "ses_pwm.h"
#include "ses_timer.h"
#include "ses_led.h"
#include "ses_uart.h"
/*FUNCTION DEFINITIONS *******************************************************************/


int main()
{
    // LEDs init
    led_redInit();
    led_greenInit();

    // Uart init
    uart_init(57600);

    // Button init and setting callback function.
    button_init(true);
    button_setJoystickButtonCallback(&motor_changestate);

    // PWM init
    pwm_init();

    //Timer init and start
    timer1_start();
    
    //enable global interrupt
    sei();
    while (1)
    {
    }

    return 0;
}
