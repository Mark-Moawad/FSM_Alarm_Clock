#include <stdint.h>
#include <avr/io.h>
/*void shortDelay (void)
{
uint16_t i; // 16 bit unsigned integer
for (i = 0x0100; i > 0 ; i--) {
//prevent code optimization by using inline assembler
asm volatile ( "nop" ); // one cycle with no operation
}
}*/
void wait(uint16_t millis)
{   /*1 wait cycle consists of: 2*nop 1 clk, sbiw 2 clk, brne 2 clk, 2*SBC 1 clk, total 8 clk cycles*/
    /*16000/8=2000*/
    uint32_t i = 0;
    for (i = (uint32_t)(millis)*2000; i > 0; i--) /*type-casting because the multiplication result doesn't fit in uint16_t*/
    {
        //prevent code optimization by using inline assembler
        asm volatile("nop"); // one cycle with no operation
        asm volatile("nop"); /* I added this line so that each loop takes exactly 8 clk cycles in order to get exact values
        not approximations*/
    }
}
int main(void)
{
    DDRG |= 0x02;
    while (1)
    {
        wait(2000);
        PORTG ^= 0x02;
    }
    return 0;
}
/*int main(void)
{
    DDRG |= 0x02;
    while (1)
    {
        _delay_ms(2000);
        PORTG ^= 0x02;
    }
    return 0;
}*/