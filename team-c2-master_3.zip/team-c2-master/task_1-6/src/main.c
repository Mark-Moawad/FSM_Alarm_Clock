#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
/*
void ReverseWithPointer(uint8_t *a)
{
    uint8_t temp1 = *a;
    for (uint8_t i = 0; i < 8; i++)
    {
        *a
    }
}
*/
uint8_t Reverse(uint8_t a)
{
    uint8_t temp = 0;
    for (uint8_t i = 0; i < 4; i++)
    {
        // a = 1101 1010 -> a = 0000 0011     0000 0000
        // temp = 1101 1010 -> 0000 0110
        temp = temp | (a >> (7 - 2 * i)) & (0x80 >> (7 - i));
    }
    for (uint8_t i = 0; i < 4; i++)
    {
        // a = 1101 1010 -> 0000 0000
        // temp = 1101 1010 -> 0000 0110
        temp = temp | (a << (7 - 2 * i)) & (0x01 << (7 - i));
    }
    return temp;
}

int main(void)
{
    uint8_t new, x = 0x95;
    new = Reverse(x);
    printf("Display new x = %02x", new);
    return 0;
}