/*INCLUDES *******************************************************************/
#include "ses_button.h"
#include "ses_pwm.h"
#include "ses_motorFrequency.h"
#include "ses_timer.h"
#include "ses_led.h"
#include "ses_lcd.h"
#include "ses_uart.h"
#include "ses_scheduler.h"

/*Variables Declaration *******************************************************************/
taskDescriptor task1;
/* Macros ********************************************************************************/
#define TASK1_PERIOD 1000
#define RPM_MULTIPLICATION_FACTOR 60
/*FUNCTION Declaration *******************************************************************/
void lcd_display(void *);

int main()
{
    //initializing taskDescriptor 1
    task1.task = lcd_display;
    task1.param = NULL;
    task1.period = TASK1_PERIOD;
    task1.expire = task1.period;
    task1.execute = false;

    // LEDs init
    led_greenInit();
    led_yellowInit();

    // Uart and LCD init
    uart_init(57600);
    lcd_init();

    // Button Init and setting call back function
    button_init(true);
    button_setJoystickButtonCallback(&motor_changestate);

    // Motor and PWM init
    motorFrequency_init();
    pwm_init();

    // Timer 1 and 5 init and start functions
    timer1_start();
    timer5_start();

    // Timer 5 setting callback
    timer5_setCallback(&calcMotorFrequency);

    // Scheduler init
    scheduler_init();

    // Adding tasks to scheduler
    scheduler_add(&task1);
    sei();
    while (1)
    {
        scheduler_run();
    }
    return 0;
}

void lcd_display(void *param)
{
    lcd_clear();
    lcd_setCursor(0, 1);
    fprintf(lcdout, "Frequency = %u RPM", (motorFrequency_getRecent() * RPM_MULTIPLICATION_FACTOR));
    fprintf(uartout, "Frequency = %u RPM \n", (motorFrequency_getRecent() * RPM_MULTIPLICATION_FACTOR));
    lcd_setCursor(0, 2);
    fprintf(lcdout, "Med Freq = %u Hz", motorFrequency_getMedian());
    fprintf(uartout, "Med Freq = %u Hz \n", motorFrequency_getMedian());
}