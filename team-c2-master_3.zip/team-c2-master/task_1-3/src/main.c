#include <stdint.h>
#include <avr/io.h>

void wait(uint16_t millis)
{
    uint32_t i = 0;
    for (i = (uint32_t)(millis)*2000; i > 0; i--)
    {
        asm volatile("nop");
        asm volatile("nop");
    }
}
int main(void)
{
    DDRG |= 0x02;
    while (1)
    {
        wait(2000);
        PORTG ^= 0x02;
    }
    return 0;
}