#include "ses_lcd.h"
#include "ses_uart.h"
#include <util/delay.h>
#include "ses_led.h"
#include "ses_button.h"

int main(void)
{
    uart_init(57600);
    lcd_init();
    led_redInit();
    led_greenInit();
    button_init();
     uint16_t sec = 0;
    while (1)
    { //task 1
        if (button_isRotaryPressed())
        {
            led_redOn();
        }
        else
        {
            led_redOff();
        }
        //task 2
        if (button_isJoystickPressed())
        {
            led_greenOn();
        }
        else
        {
            led_greenOff();
        }

        //task 3
        lcd_clear();
        sec++;
        fprintf(lcdout, "%d", sec);
        _delay_ms(1000);
    }
    return 0;
}