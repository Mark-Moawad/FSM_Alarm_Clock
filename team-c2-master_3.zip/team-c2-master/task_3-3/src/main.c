#include "ses_lcd.h"
#include "ses_uart.h"
#include <util/delay.h>
#include "ses_led.h"
#include "ses_button.h"
#include "ses_adc.h"
#include "ses_timer.h"

int main(void)
{
    button_init(true);
    led_greenInit();
    led_redInit();
    uart_init(57600);
    button_setRotaryButtonCallback(&led_greenToggle);
    button_setJoystickButtonCallback(&led_redToggle);
    timer1_start();
    sei();
    while (1)
    {
        /* code */
    }

    return 0;
}