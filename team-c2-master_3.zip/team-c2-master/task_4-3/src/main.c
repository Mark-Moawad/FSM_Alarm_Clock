// /*INCLUDES *******************************************************************/
// #include "pscheduler.h"

// /*FUNCTION DEFINITIONS *******************************************************************/
// void taskA(void)
// {
//     while (1)
//     {
//     }
// }
// void taskB(void)
// {
//     while (1)
//     {
//     }
// }
// void taskC(void)
// {
//     while (1)
//     {
//     }
// }
// /*IMPLEMENTATION *******************************************************************/
// task_t taskList[] = {&taskA, &taskB, &taskC};
// uint8_t numTasks = 3;
// int main(void)
// {
//     pscheduler_run(taskList, numTasks);
//     return 0;
// }