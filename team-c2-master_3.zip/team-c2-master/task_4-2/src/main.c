#include "ses_lcd.h"
#include "ses_uart.h"
#include <util/delay.h>
#include "ses_led.h"
#include "ses_button.h"
#include "ses_adc.h"
#include "ses_timer.h"
#include "ses_scheduler.h"
#include "util/atomic.h"

/* Debugging Macros ******************************************/
#define _DEBUG 1

#if _DEBUG == 1
#define UART_DEBUG(value) fprintf(uartout, "%d   ", value)
#else
#define UART_DEBUG(value)
#endif // _DEBUG

typedef enum
{
    red,
    yellow,
    green
} led_color;

led_color task1_param = green;
taskDescriptor task1, task2, task3, task4, task5, task6;

uint8_t stopwatchState;
uint8_t ledState;

uint16_t tenth = 0;
uint16_t seconds = 0;

void func_task1(void *);
void func_task2(void *);
void func_task3(void *);
void func_task4(void *);
void func_task5(void *);
void func_task6(void *);
void stopWatch(void);
void ledButtonControl(void);
// task initialization macros

#define task1_period 500
#define task2_period 5
#define task3_period 0
#define task4_period 5000
#define task5_period 100
#define task6_period 0

#define ON 1
#define OFF 0

int main(void)
{

    //initializing taskDescriptor 1
    task1.task = func_task1;
    task1.param = &task1_param;
    task1.period = task1_period;
    task1.expire = task1.period;
    task1.execute = false;

    //initializing taskDescriptor 2
    task2.task = func_task2;
    task2.param = NULL;
    task2.period = task2_period;
    task2.expire = task2.period;
    task2.execute = false;

    //initializing taskDescriptor 3
    task3.task = func_task3;
    task3.param = NULL;
    task3.period = task3_period;
    task3.expire = task3.period;
    task3.execute = false;
    ledState = OFF;

    //initializing taskDescriptor 4
    task4.task = func_task4;
    task4.param = NULL;
    task4.period = task4_period;
    task4.expire = task4.period;
    task4.execute = false;

    //initializing taskDescriptor 5
    task5.task = func_task5;
    task5.param = NULL;
    task5.period = task5_period;
    task5.expire = task5.period;
    task5.execute = false;

    //initializing taskDescriptor 6
    task6.task = func_task6;
    task6.param = NULL;
    task6.period = task6_period;
    task6.expire = task6.period;
    task6.execute = false;
    stopwatchState = OFF;

    button_init(true);
    led_greenInit();
    led_redInit();
    led_yellowInit();
    lcd_init();
    uart_init(57600);
    button_setJoystickButtonCallback(&ledButtonControl);
    button_setRotaryButtonCallback(&stopWatch);
    scheduler_init();
    scheduler_add(&task1);
    scheduler_add(&task2);
    while (1)
    {
        scheduler_run();
    }
    return 0;
}

void func_task1(void *led)
{
    uint8_t leds = *((uint8_t *)led);
    if (leds == red)
    {
        led_redToggle();
    }
    else if (leds == green)
    {
        led_greenToggle();
    }
    else if (leds == yellow)
    {
        led_yellowToggle();
    }
}
void func_task2(void *number)
{
    button_checkState();
}
void func_task3(void *number)
{
    if (ledState == OFF)
    {
        led_yellowOn();
        task4.execute = 0;
        task4.expire = task4.period;
        scheduler_add(&task4);
        ledState = ON;
    }
    else
    {
        led_yellowOff();
        scheduler_remove(&task4);
        ledState = OFF;
    }
}
void func_task4(void *number)
{
    led_yellowOff();
    scheduler_remove(&task4);
    ledState = OFF;
}
void func_task5(void *number)
{

    tenth++;
    seconds = tenth / 10;
    lcd_clear();
    lcd_setCursor(0,1);
    fprintf(lcdout, "Seconds: %d,%d", seconds, tenth);
}
void func_task6(void *number)
{

    if (stopwatchState == OFF)
    {
        task5.execute = 0;
        task5.expire = task5.period;
        scheduler_add(&task5);
        stopwatchState = ON;
    }
    else
    {
        scheduler_remove(&task5);
        stopwatchState = OFF;
    }
}

void stopWatch()
{
    scheduler_add(&task6);
    task6.execute = 1;
}
void ledButtonControl()
{
    scheduler_add(&task3);
    task3.execute = 1;
}
